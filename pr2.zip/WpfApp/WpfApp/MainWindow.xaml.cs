﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace JsonPlaceholderWpf
{
    // ===== 1. МОДЕЛЬ =====
    public class Todo
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("userId")]
        public int UserId { get; set; }

        [JsonPropertyName("title")]
        public string Title { get; set; } = string.Empty;

        [JsonPropertyName("completed")]
        public bool Completed { get; set; }

        public override string ToString()
            => $"ID: {Id,-4} | [{(Completed ? "✓" : " ")}] {Title}";
    }

    // ===== 2. СЕРВИС =====
    public class TodoService
    {
        private readonly HttpClient _http;

        public TodoService()
        {
            _http = new HttpClient
            {
                BaseAddress = new Uri("https://jsonplaceholder.typicode.com/")
            };
        }

        // GET /todos?userId={id}
        public async Task<List<Todo>> GetUserTodosAsync(int userId)
        {
            using var response = await _http.GetAsync($"todos?userId={userId}");
            await EnsureSuccessAsync(response);
            return await response.Content.ReadFromJsonAsync<List<Todo>>()
                   ?? new List<Todo>();
        }

        // GET /todos/{id}
        public async Task<Todo?> GetTodoByIdAsync(int id)
        {
            using var response = await _http.GetAsync($"todos/{id}");
            if (response.StatusCode == HttpStatusCode.NotFound)
                return null;
            await EnsureSuccessAsync(response);
            return await response.Content.ReadFromJsonAsync<Todo>();
        }

        // POST /todos
        public async Task<Todo?> CreateTodoAsync(Todo todo)
        {
            using var response = await _http.PostAsJsonAsync("todos", todo);
            await EnsureSuccessAsync(response);
            return await response.Content.ReadFromJsonAsync<Todo>();
        }

        // PATCH /todos/{id}
        public async Task<Todo?> PatchTodoAsync(int id, object patch)
        {
            using var request = new HttpRequestMessage(HttpMethod.Patch, $"todos/{id}")
            {
                Content = JsonContent.Create(patch)
            };
            using var response = await _http.SendAsync(request);
            await EnsureSuccessAsync(response);
            return await response.Content.ReadFromJsonAsync<Todo>();
        }

        // DELETE /todos/{id}
        public async Task<bool> DeleteTodoAsync(int id)
        {
            using var response = await _http.DeleteAsync($"todos/{id}");
            await EnsureSuccessAsync(response);
            return response.IsSuccessStatusCode;
        }

        private static async Task EnsureSuccessAsync(HttpResponseMessage response)
        {
            if (!response.IsSuccessStatusCode)
            {
                string body = await response.Content.ReadAsStringAsync();
                throw new HttpRequestException(
                    $"HTTP {(int)response.StatusCode} {response.ReasonPhrase}. {body}");
            }
        }
    }

    // ===== 3. ОКНО =====
    public partial class MainWindow : Window
    {
        private readonly TodoService _service = new TodoService();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Log(string message) => OutputList.Items.Add(message);
        private void ClearLog() => OutputList.Items.Clear();

        private bool TryGetInt(TextBox box, string name, out int value)
        {
            if (int.TryParse(box.Text.Trim(), out value)) return true;
            MessageBox.Show($"Введите корректное значение для «{name}».",
                "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        // 1. Показать задачи пользователя
        private async void ShowUserTodos_Click(object sender, RoutedEventArgs e)
        {
            if (!TryGetInt(UserIdBox, "ID пользователя", out int userId)) return;

            ClearLog();
            try
            {
                List<Todo> todos = await _service.GetUserTodosAsync(userId);
                if (todos.Count == 0)
                {
                    Log($"У пользователя {userId} нет задач.");
                    return;
                }

                Log($"Задачи пользователя {userId} (всего: {todos.Count}):");
                foreach (var t in todos)
                    Log(t.ToString());
            }
            catch (Exception ex)
            {
                Log($"Ошибка: {ex.Message}");
            }
        }

        // 2. Найти задачу по ID
        private async void FindById_Click(object sender, RoutedEventArgs e)
        {
            if (!TryGetInt(TodoIdBox, "ID задачи", out int id)) return;

            ClearLog();
            try
            {
                Todo? todo = await _service.GetTodoByIdAsync(id);
                if (todo is null)
                {
                    Log($"Задача с ID {id} не найдена (404).");
                }
                else
                {
                    Log("Найдена задача:");
                    Log(todo.ToString());
                }
            }
            catch (Exception ex)
            {
                Log($"Ошибка: {ex.Message}");
            }
        }

        // 3. Создать задачу
        private async void Create_Click(object sender, RoutedEventArgs e)
        {
            if (!TryGetInt(UserIdBox, "ID пользователя", out int userId)) return;

            if (string.IsNullOrWhiteSpace(TitleBox.Text))
            {
                MessageBox.Show("Введите название задачи.",
                    "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ClearLog();
            try
            {
                var newTodo = new Todo
                {
                    UserId = userId,
                    Title = TitleBox.Text.Trim(),
                    Completed = CompletedBox.IsChecked == true
                };

                Todo? created = await _service.CreateTodoAsync(newTodo);
                if (created is null)
                {
                    Log("Сервер вернул пустой ответ.");
                    return;
                }

                Log("Задача создана (сервер имитирует сохранение):");
                Log(created.ToString());
            }
            catch (Exception ex)
            {
                Log($"Ошибка: {ex.Message}");
            }
        }

        // 4. Изменить статус задачи (PATCH)
        private async void Patch_Click(object sender, RoutedEventArgs e)
        {
            if (!TryGetInt(TodoIdBox, "ID задачи", out int id)) return;

            ClearLog();
            try
            {
                var patch = new { completed = CompletedBox.IsChecked == true };
                Todo? updated = await _service.PatchTodoAsync(id, patch);

                if (updated is null)
                {
                    Log("Сервер вернул пустой ответ.");
                    return;
                }

                Log($"Задача {id} обновлена (PATCH):");
                Log(updated.ToString());
            }
            catch (Exception ex)
            {
                Log($"Ошибка: {ex.Message}");
            }
        }

        // 5. Удалить задачу
        private async void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (!TryGetInt(TodoIdBox, "ID задачи", out int id)) return;

            ClearLog();
            try
            {
                bool ok = await _service.DeleteTodoAsync(id);
                Log(ok
                    ? $"Задача {id} удалена (ответ 200 OK, изменение имитируется)."
                    : $"Не удалось удалить задачу {id}.");
            }
            catch (Exception ex)
            {
                Log($"Ошибка: {ex.Message}");
            }
        }

        // 0. Выход
        private void Exit_Click(object sender, RoutedEventArgs e) => Close();
    }
}