using System.Security.Claims;
using ClothesStore.Api.Data;
using ClothesStore.Api.Dtos;
using ClothesStore.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ClothesStore.Api.Controllers;

/// <summary>Операции с заказами.</summary>
[ApiController]
[Route("api/[controller]")]
[Authorize] // Весь контроллер доступен только авторизованным пользователям.
public class OrdersController : ControllerBase
{
    private readonly AppDbContext _context;

    public OrdersController(AppDbContext context)
    {
        _context = context;
    }

    /// <summary>Создать новый заказ. Доступно при авторизации.</summary>
    [HttpPost]
    public async Task<ActionResult<OrderDto>> CreateOrder(CreateOrderRequest request)
    {
        if (request.Items is null || request.Items.Count == 0)
        {
            return BadRequest("Заказ должен содержать хотя бы один товар.");
        }

        var userId = GetCurrentUserId();

        // Загружаем заказанные размеры вместе с товарами.
        var sizeIds = request.Items.Select(i => i.SizeId).Distinct().ToList();
        var sizes = await _context.Sizes
            .Include(s => s.Cloth)
            .Where(s => sizeIds.Contains(s.Id))
            .ToListAsync();

        var order = new Order
        {
            CreatedAt = DateTime.UtcNow,
            Status = OrderStatus.New,
            UserId = userId,
            Items = new List<OrderItem>()
        };

        foreach (var item in request.Items)
        {
            var size = sizes.FirstOrDefault(s => s.Id == item.SizeId);
            if (size is null)
            {
                return BadRequest($"Размер с Id={item.SizeId} не найден.");
            }

            // Проверяем, что товар в заказе соответствует размеру.
            if (item.ClothId != size.ClothId)
            {
                return BadRequest("Размер не принадлежит указанному товару.");
            }

            if (!size.Cloth.IsAvailable)
            {
                return BadRequest($"Товар \"{size.Cloth.Name}\" снят с продажи.");
            }

            if (item.Quantity <= 0)
            {
                return BadRequest("Количество должно быть больше нуля.");
            }

            if (size.StockQuantity < item.Quantity)
            {
                return BadRequest($"Недостаточно товара размера {size.Letter} на складе.");
            }

            // Уменьшаем остаток и увеличиваем счётчик покупок.
            size.StockQuantity -= item.Quantity;
            size.Cloth.PurchaseCount += item.Quantity;

            order.Items.Add(new OrderItem
            {
                ClothId = size.ClothId,
                SizeId = size.Id,
                Quantity = item.Quantity,
                UnitPrice = size.Cloth.Price
            });
        }

        _context.Orders.Add(order);
        await _context.SaveChangesAsync();

        var created = await LoadOrderDto(order.Id);
        return CreatedAtAction(nameof(GetOrdersByStatus), new { }, created);
    }

    /// <summary>Получить список заказов с определённым статусом. Доступно при авторизации.</summary>
    [HttpGet("by-status")]
    public async Task<ActionResult<IEnumerable<OrderDto>>> GetOrdersByStatus([FromQuery] OrderStatus status)
    {
        var orders = await _context.Orders
            .Where(o => o.Status == status)
            .Include(o => o.User)
            .Include(o => o.Items).ThenInclude(i => i.Cloth)
            .Include(o => o.Items).ThenInclude(i => i.Size)
            .AsNoTracking()
            .ToListAsync();

        return Ok(orders.Select(ToDto));
    }

    /// <summary>Получить список заказов определённого покупателя. Доступно при авторизации.</summary>
    [HttpGet("by-user/{userId:int}")]
    public async Task<ActionResult<IEnumerable<OrderDto>>> GetOrdersByUser(int userId)
    {
        var orders = await _context.Orders
            .Where(o => o.UserId == userId)
            .Include(o => o.User)
            .Include(o => o.Items).ThenInclude(i => i.Cloth)
            .Include(o => o.Items).ThenInclude(i => i.Size)
            .AsNoTracking()
            .ToListAsync();

        return Ok(orders.Select(ToDto));
    }

    /// <summary>Изменить статус существующего заказа. Только менеджер.</summary>
    [HttpPut("{id:int}/status")]
    [Authorize(Roles = nameof(UserRole.Manager))]
    public async Task<IActionResult> UpdateStatus(int id, UpdateOrderStatusRequest request)
    {
        var order = await _context.Orders.FindAsync(id);
        if (order is null)
        {
            return NotFound("Заказ не найден.");
        }

        order.Status = request.Status;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private async Task<OrderDto?> LoadOrderDto(int id)
    {
        var order = await _context.Orders
            .Include(o => o.User)
            .Include(o => o.Items).ThenInclude(i => i.Cloth)
            .Include(o => o.Items).ThenInclude(i => i.Size)
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.Id == id);

        return order is null ? null : ToDto(order);
    }

    private int GetCurrentUserId()
    {
        var idClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return int.Parse(idClaim!);
    }

    private static OrderDto ToDto(Order o) => new(
        o.Id,
        o.CreatedAt,
        new OrderStatusDto((int)o.Status, o.Status.ToString()),
        o.UserId,
        o.User.Login,
        o.Items.Select(i => new OrderItemDto(
            i.Id,
            i.ClothId,
            i.Cloth.Name,
            i.SizeId,
            i.Size.Letter,
            i.Quantity,
            i.UnitPrice)).ToList());
}
