using ClothesStore.Api.Data;
using ClothesStore.Api.Dtos;
using ClothesStore.Api.Models;
using ClothesStore.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ClothesStore.Api.Controllers;

/// <summary>Авторизация и регистрация пользователей.</summary>
[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly TokenService _tokenService;

    public AuthController(AppDbContext context, TokenService tokenService)
    {
        _context = context;
        _tokenService = tokenService;
    }

    /// <summary>Регистрация нового пользователя. Доступна любому.</summary>
    [HttpPost("register")]
    public async Task<ActionResult<AuthResponse>> Register(RegisterRequest request)
    {
        var login = request.Login.Trim();

        if (await _context.Users.AnyAsync(u => u.Login == login))
        {
            return Conflict("Пользователь с таким логином уже существует.");
        }

        // Регистрироваться может любой, но только как обычный пользователь.
        var user = new User
        {
            Login = login,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
            Phone = request.Phone,
            DeliveryAddress = request.DeliveryAddress,
            Role = UserRole.User
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return Ok(BuildAuthResponse(user));
    }

    /// <summary>Вход в систему.</summary>
    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login(LoginRequest request)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Login == request.Login.Trim());

        if (user is null || !BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash))
        {
            return Unauthorized("Неверный логин или пароль.");
        }

        return Ok(BuildAuthResponse(user));
    }

    private AuthResponse BuildAuthResponse(User user) =>
        new(_tokenService.CreateToken(user), user.Id, user.Login, user.Role.ToString());
}
