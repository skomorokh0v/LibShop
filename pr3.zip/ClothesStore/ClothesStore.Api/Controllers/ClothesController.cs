using ClothesStore.Api.Data;
using ClothesStore.Api.Dtos;
using ClothesStore.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ClothesStore.Api.Controllers;

/// <summary>Операции с одеждой: просмотр, поиск, управление наличием и продажей.</summary>
[ApiController]
[Route("api/[controller]")]
public class ClothesController : ControllerBase
{
    private readonly AppDbContext _context;

    public ClothesController(AppDbContext context)
    {
        _context = context;
    }

    /// <summary>Получить список всей одежды. Доступно без авторизации.</summary>
    [HttpGet]
    [AllowAnonymous]
    public async Task<ActionResult<IEnumerable<ClothDto>>> GetAll()
    {
        var clothes = await _context.Clothes
            .Include(c => c.ClothType)
            .Include(c => c.Sizes)
            .AsNoTracking()
            .ToListAsync();

        return Ok(clothes.Select(ToDto));
    }

    /// <summary>Поиск одежды по части названия. Доступно без авторизации.</summary>
    [HttpGet("search")]
    [AllowAnonymous]
    public async Task<ActionResult<IEnumerable<ClothDto>>> Search([FromQuery] string name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return BadRequest("Параметр name не может быть пустым.");
        }

        var query = name.Trim();

        var clothes = await _context.Clothes
            .Include(c => c.ClothType)
            .Include(c => c.Sizes)
            .Where(c => EF.Functions.Like(c.Name, $"%{query}%"))
            .AsNoTracking()
            .ToListAsync();

        return Ok(clothes.Select(ToDto));
    }

    /// <summary>Изменить количество товара определённого размера. Только менеджер.</summary>
    [HttpPut("sizes/{sizeId:int}/stock")]
    [Authorize(Roles = nameof(UserRole.Manager))]
    public async Task<IActionResult> UpdateStock(int sizeId, UpdateStockRequest request)
    {
        if (request.StockQuantity < 0)
        {
            return BadRequest("Количество не может быть отрицательным.");
        }

        var size = await _context.Sizes.FindAsync(sizeId);
        if (size is null)
        {
            return NotFound("Размер не найден.");
        }

        size.StockQuantity = request.StockQuantity;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    /// <summary>Убрать товар из продажи. Только менеджер.</summary>
    [HttpPost("{id:int}/remove-from-sale")]
    [Authorize(Roles = nameof(UserRole.Manager))]
    public async Task<IActionResult> RemoveFromSale(int id)
    {
        var cloth = await _context.Clothes.FindAsync(id);
        if (cloth is null)
        {
            return NotFound("Товар не найден.");
        }

        cloth.IsAvailable = false;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    /// <summary>Вернуть товар в продажу. Только менеджер.</summary>
    [HttpPost("{id:int}/restore-to-sale")]
    [Authorize(Roles = nameof(UserRole.Manager))]
    public async Task<IActionResult> RestoreToSale(int id)
    {
        var cloth = await _context.Clothes.FindAsync(id);
        if (cloth is null)
        {
            return NotFound("Товар не найден.");
        }

        cloth.IsAvailable = true;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private static ClothDto ToDto(Cloth c) => new(
        c.Id,
        c.Name,
        c.Price,
        c.Description,
        c.PurchaseCount,
        c.IsAvailable,
        c.ClothType.Name,
        c.Sizes.Select(s => new SizeDto(s.Id, s.Letter, s.Number, s.StockQuantity)).ToList());
}
