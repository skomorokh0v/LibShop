namespace ClothesStore.Api.Models;

/// <summary>Размер конкретного товара и его наличие на складе.</summary>
public class Size
{
    public int Id { get; set; }

    /// <summary>Буквенное обозначение размера, например S, M, L, XL.</summary>
    public string Letter { get; set; } = null!;

    /// <summary>Числовое обозначение размера.</summary>
    public int Number { get; set; }

    /// <summary>Количество товара данного размера в наличии.</summary>
    public int StockQuantity { get; set; }

    /// <summary>Внешний ключ на товар.</summary>
    public int ClothId { get; set; }

    /// <summary>Товар, к которому относится размер.</summary>
    public Cloth Cloth { get; set; } = null!;
}
