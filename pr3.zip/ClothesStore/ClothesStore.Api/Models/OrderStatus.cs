namespace ClothesStore.Api.Models;

/// <summary>Статус заказа.</summary>
public enum OrderStatus
{
    /// <summary>Новый, создан покупателем.</summary>
    New = 0,
    /// <summary>Подтверждён менеджером.</summary>
    Confirmed = 1,
    /// <summary>Передан в доставку.</summary>
    Shipped = 2,
    /// <summary>Выполнен.</summary>
    Completed = 3,
    /// <summary>Отменён.</summary>
    Cancelled = 4
}
