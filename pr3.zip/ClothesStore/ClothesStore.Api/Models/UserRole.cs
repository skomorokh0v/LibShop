namespace ClothesStore.Api.Models;

/// <summary>Роль пользователя в системе.</summary>
public enum UserRole
{
    User = 0,
    Manager = 1
}
