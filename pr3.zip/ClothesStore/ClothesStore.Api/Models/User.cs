namespace ClothesStore.Api.Models;

/// <summary>Покупатель / пользователь системы.</summary>
public class User
{
    public int Id { get; set; }

    /// <summary>Логин для входа в систему.</summary>
    public string Login { get; set; } = null!;

    /// <summary>Хеш пароля (никогда не храним пароль в открытом виде).</summary>
    public string PasswordHash { get; set; } = null!;

    /// <summary>Номер телефона.</summary>
    public string Phone { get; set; } = null!;

    /// <summary>Адрес доставки.</summary>
    public string DeliveryAddress { get; set; } = null!;

    /// <summary>Роль пользователя.</summary>
    public UserRole Role { get; set; } = UserRole.User;

    /// <summary>Заказы, оформленные данным покупателем.</summary>
    public List<Order> Orders { get; set; } = [];
}
