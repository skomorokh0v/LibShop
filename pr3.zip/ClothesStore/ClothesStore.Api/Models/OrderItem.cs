namespace ClothesStore.Api.Models;

/// <summary>Позиция заказа: конкретный товар, его размер и количество.</summary>
public class OrderItem
{
    public int Id { get; set; }

    /// <summary>Внешний ключ на заказ.</summary>
    public int OrderId { get; set; }

    /// <summary>Заказ, к которому относится позиция.</summary>
    public Order Order { get; set; } = null!;

    /// <summary>Внешний ключ на товар.</summary>
    public int ClothId { get; set; }

    /// <summary>Заказанный товар.</summary>
    public Cloth Cloth { get; set; } = null!;

    /// <summary>Внешний ключ на размер.</summary>
    public int SizeId { get; set; }

    /// <summary>Заказанный размер.</summary>
    public Size Size { get; set; } = null!;

    /// <summary>Количество единиц данного размера в заказе.</summary>
    public int Quantity { get; set; }

    /// <summary>Цена за единицу на момент оформления заказа.</summary>
    public decimal UnitPrice { get; set; }
}
