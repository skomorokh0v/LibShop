namespace ClothesStore.Api.Models;

/// <summary>Тип одежды (футболка, худи и т.п.).</summary>
public class ClothType
{
    public int Id { get; set; }

    /// <summary>Название типа, например "Футболка".</summary>
    public string Name { get; set; } = null!;

    public List<Cloth> Clothes { get; set; } = [];
}
