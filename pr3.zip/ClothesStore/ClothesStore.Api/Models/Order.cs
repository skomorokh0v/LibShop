namespace ClothesStore.Api.Models;

/// <summary>Заказ, оформленный покупателем.</summary>
public class Order
{
    public int Id { get; set; }

    /// <summary>Дата и время создания заказа.</summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>Текущий статус заказа.</summary>
    public OrderStatus Status { get; set; } = OrderStatus.New;

    /// <summary>Внешний ключ на покупателя.</summary>
    public int UserId { get; set; }

    /// <summary>Покупатель, оформивший заказ.</summary>
    public User User { get; set; } = null!;

    /// <summary>Список заказанных товаров с их размерами.</summary>
    public List<OrderItem> Items { get; set; } = [];
}
