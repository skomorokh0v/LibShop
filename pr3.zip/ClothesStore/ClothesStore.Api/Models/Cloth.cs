namespace ClothesStore.Api.Models;

/// <summary>Товар (одежда).</summary>
public class Cloth
{
    public int Id { get; set; }

    /// <summary>Название товара.</summary>
    public string Name { get; set; } = null!;

    /// <summary>Цена товара.</summary>
    public decimal Price { get; set; }

    /// <summary>Описание товара.</summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>Количество покупок данного товара.</summary>
    public int PurchaseCount { get; set; }

    /// <summary>Доступен ли товар для продажи.</summary>
    public bool IsAvailable { get; set; } = true;

    /// <summary>Внешний ключ на тип одежды.</summary>
    public int ClothTypeId { get; set; }

    /// <summary>Тип одежды.</summary>
    public ClothType ClothType { get; set; } = null!;

    /// <summary>Размеры товара и их наличие.</summary>
    public List<Size> Sizes { get; set; } = [];
}
