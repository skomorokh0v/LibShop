using ClothesStore.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace ClothesStore.Api.Data;

/// <summary>Контекст базы данных приложения.</summary>
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<User> Users => Set<User>();
    public DbSet<Cloth> Clothes => Set<Cloth>();
    public DbSet<ClothType> ClothTypes => Set<ClothType>();
    public DbSet<Size> Sizes => Set<Size>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Логин должен быть уникальным.
        modelBuilder.Entity<User>()
            .HasIndex(u => u.Login)
            .IsUnique();

        // У одного товара не может быть двух одинаковых размеров.
        modelBuilder.Entity<Size>()
            .HasIndex(s => new { s.ClothId, s.Letter })
            .IsUnique();

        // Цена хранится с двумя знаками после запятой.
        modelBuilder.Entity<Cloth>()
            .Property(c => c.Price)
            .HasPrecision(10, 2);

        modelBuilder.Entity<OrderItem>()
            .Property(oi => oi.UnitPrice)
            .HasPrecision(10, 2);

        // Пользователь -> заказы (1 ко многим).
        modelBuilder.Entity<Order>()
            .HasOne(o => o.User)
            .WithMany(u => u.Orders)
            .HasForeignKey(o => o.UserId)
            .OnDelete(DeleteBehavior.Restrict);

        // Тип одежды -> товары (1 ко многим).
        modelBuilder.Entity<Cloth>()
            .HasOne(c => c.ClothType)
            .WithMany(t => t.Clothes)
            .HasForeignKey(c => c.ClothTypeId)
            .OnDelete(DeleteBehavior.Restrict);

        // Товар -> размеры (1 ко многим).
        modelBuilder.Entity<Size>()
            .HasOne(s => s.Cloth)
            .WithMany(c => c.Sizes)
            .HasForeignKey(s => s.ClothId)
            .OnDelete(DeleteBehavior.Cascade);

        // Заказ -> позиции заказа (1 ко многим).
        modelBuilder.Entity<OrderItem>()
            .HasOne(oi => oi.Order)
            .WithMany(o => o.Items)
            .HasForeignKey(oi => oi.OrderId)
            .OnDelete(DeleteBehavior.Cascade);

        // Позиция заказа -> товар.
        modelBuilder.Entity<OrderItem>()
            .HasOne(oi => oi.Cloth)
            .WithMany()
            .HasForeignKey(oi => oi.ClothId)
            .OnDelete(DeleteBehavior.Restrict);

        // Позиция заказа -> размер.
        modelBuilder.Entity<OrderItem>()
            .HasOne(oi => oi.Size)
            .WithMany()
            .HasForeignKey(oi => oi.SizeId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
