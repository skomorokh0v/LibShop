using ClothesStore.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace ClothesStore.Api.Data;

/// <summary>
/// Сервис инициализации базы данных: применяет миграции и наполняет БД стартовыми данными.
/// </summary>
public static class DbInitializer
{
    public static async Task InitializeAsync(IServiceProvider serviceProvider)
    {
        using var scope = serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        // Гарантируем создание схемы (EnsureCreated также подходит для быстрого старта).
        await context.Database.MigrateAsync();

        if (await context.Users.AnyAsync())
        {
            return; // БД уже наполнена.
        }

        // Пользователи. Пароли хранятся в виде хеша.
        var manager = new User
        {
            Login = "manager",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("manager123"),
            Phone = "+70000000001",
            DeliveryAddress = "Офис, ул. Центральная, 1",
            Role = UserRole.Manager
        };

        var customer = new User
        {
            Login = "user",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("user123"),
            Phone = "+70000000002",
            DeliveryAddress = "ул. Ленина, 10, кв. 5",
            Role = UserRole.User
        };

        context.Users.AddRange(manager, customer);

        // Типы одежды.
        var tshirt = new ClothType { Name = "Футболка" };
        var hoodie = new ClothType { Name = "Худи" };
        var polo = new ClothType { Name = "Поло" };
        context.ClothTypes.AddRange(tshirt, hoodie, polo);

        // Товары.
        var cloths = new List<Cloth>
        {
            new()
            {
                Name = "Футболка Классика",
                Price = 1499.00m,
                Description = "Хлопковая футболка прямого кроя.",
                PurchaseCount = 12,
                IsAvailable = true,
                ClothType = tshirt,
                Sizes = new List<Size>
                {
                    new() { Letter = "S",  Number = 44, StockQuantity = 20 },
                    new() { Letter = "M",  Number = 48, StockQuantity = 35 },
                    new() { Letter = "L",  Number = 52, StockQuantity = 25 },
                    new() { Letter = "XL", Number = 56, StockQuantity = 10 },
                }
            },
            new()
            {
                Name = "Футболка Оверсайз",
                Price = 1899.00m,
                Description = "Свободного силуэта, плотный хлопок.",
                PurchaseCount = 30,
                IsAvailable = true,
                ClothType = tshirt,
                Sizes = new List<Size>
                {
                    new() { Letter = "M",  Number = 48, StockQuantity = 15 },
                    new() { Letter = "L",  Number = 52, StockQuantity = 8 },
                    new() { Letter = "XL", Number = 56, StockQuantity = 5 },
                }
            },
            new()
            {
                Name = "Худи с капюшоном",
                Price = 3999.00m,
                Description = "Тёплое худи с начесом.",
                PurchaseCount = 5,
                IsAvailable = true,
                ClothType = hoodie,
                Sizes = new List<Size>
                {
                    new() { Letter = "S",  Number = 44, StockQuantity = 7 },
                    new() { Letter = "M",  Number = 48, StockQuantity = 12 },
                    new() { Letter = "L",  Number = 52, StockQuantity = 4 },
                }
            },
            new()
            {
                Name = "Поло Базовое",
                Price = 2499.00m,
                Description = "Классическое поло из пике.",
                PurchaseCount = 8,
                IsAvailable = true,
                ClothType = polo,
                Sizes = new List<Size>
                {
                    new() { Letter = "M",  Number = 48, StockQuantity = 18 },
                    new() { Letter = "L",  Number = 52, StockQuantity = 14 },
                }
            }
        };

        context.Clothes.AddRange(cloths);
        await context.SaveChangesAsync();

        // Демонстрационный заказ.
        var firstCloth = cloths[0];
        var firstSize = firstCloth.Sizes.First();

        var order = new Order
        {
            CreatedAt = DateTime.UtcNow.AddDays(-1),
            Status = OrderStatus.New,
            User = customer,
            Items = new List<OrderItem>
            {
                new()
                {
                    Cloth = firstCloth,
                    Size = firstSize,
                    Quantity = 2,
                    UnitPrice = firstCloth.Price
                }
            }
        };

        context.Orders.Add(order);
        await context.SaveChangesAsync();
    }
}
