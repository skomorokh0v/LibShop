namespace ClothesStore.Api.Dtos;

/// <summary>Короткое представление размера.</summary>
public record SizeDto(
    int Id,
    string Letter,
    int Number,
    int StockQuantity);

/// <summary>Представление товара для вывода.</summary>
public record ClothDto(
    int Id,
    string Name,
    decimal Price,
    string Description,
    int PurchaseCount,
    bool IsAvailable,
    string ClothType,
    List<SizeDto> Sizes);

/// <summary>Элемент заказа для вывода.</summary>
public record OrderItemDto(
    int Id,
    int ClothId,
    string ClothName,
    int SizeId,
    string SizeLetter,
    int Quantity,
    decimal UnitPrice);

/// <summary>Представление заказа для вывода.</summary>
public record OrderDto(
    int Id,
    DateTime CreatedAt,
    OrderStatusDto Status,
    int UserId,
    string UserLogin,
    List<OrderItemDto> Items);

/// <summary>Статус заказа в виде строки и числа.</summary>
public record OrderStatusDto(
    int Value,
    string Name);

/// <summary>Запрос на создание заказа.</summary>
public record CreateOrderRequest(
    List<CreateOrderItemRequest> Items);

/// <summary>Элемент при создании заказа.</summary>
public record CreateOrderItemRequest(
    int ClothId,
    int SizeId,
    int Quantity);

/// <summary>Запрос на изменение количества товара размера.</summary>
public record UpdateStockRequest(int StockQuantity);

/// <summary>Запрос на изменение статуса заказа.</summary>
public record UpdateOrderStatusRequest(Models.OrderStatus Status);
