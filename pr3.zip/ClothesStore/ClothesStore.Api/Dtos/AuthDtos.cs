namespace ClothesStore.Api.Dtos;

/// <summary>Данные для регистрации нового пользователя.</summary>
public record RegisterRequest(
    string Login,
    string Password,
    string Phone,
    string DeliveryAddress);

/// <summary>Данные для входа в систему.</summary>
public record LoginRequest(
    string Login,
    string Password);

/// <summary>Ответ с токеном авторизации.</summary>
public record AuthResponse(
    string Token,
    int UserId,
    string Login,
    string Role);
