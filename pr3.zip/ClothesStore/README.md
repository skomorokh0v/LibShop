# ClothesStore API

API для интернет-магазина одежды (в первую очередь — футболок). Реализовано на **ASP.NET Core (.NET 10)** с использованием **Entity Framework Core (SQLite)**, **JWT-авторизации** и разделением ролей (пользователь / менеджер).

## Стек

- ASP.NET Core Web API (.NET 10)
- Entity Framework Core + SQLite (миграции)
- JWT Bearer-аутентификация
- BCrypt для хеширования паролей
- Swagger (Swashbuckle) с поддержкой Bearer-токена
- Docker (Dockerfile для сборки образа)

## Запуск локально

```bash
cd ClothesStore.Api
dotnet run
```

Swagger UI будет доступен по адресу: `https://localhost:<port>/swagger` (в режиме Development).
При старте приложение автоматически применяет миграции и наполняет БД стартовыми данными (seed).

### Тестовые пользователи

| Логин     | Пароль       | Роль      |
|-----------|--------------|-----------|
| `manager` | `manager123` | Manager   |
| `user`    | `user123`    | User      |

## Запуск в Docker

Dockerfile находится в папке `ClothesStore.Api`. Сборка образа выполняется из этой папки:

```bash
cd ClothesStore.Api
docker build -t clothesstore-api .
docker run -p 8080:8080 clothesstore-api
```

API будет доступен по адресу `http://localhost:8080`.

## Архитектура проекта

```
ClothesStore.Api/
├── Controllers/      # Контроллеры API (Auth, Clothes, Orders)
├── Data/             # AppDbContext + DbInitializer (миграции + seed)
├── Dtos/             # DTO для запросов и ответов
├── Models/           # Сущности домена (User, Cloth, Size, Order, OrderItem, enum'ы)
├── Services/         # TokenService (генерация JWT)
├── Migrations/       # Миграции EF Core
├── Program.cs        # Конфигурация приложения
└── Dockerfile
```

## Модель данных

- **User** — покупатель/пользователь: логин, хеш пароля, телефон, адрес доставки, роль (User/Manager). Связан с заказами (1-ко-многим).
- **Cloth** — товар: название, цена, описание, количество покупок, тип одежды, флаг доступности к продаже.
- **ClothType** — тип одежды (Футболка, Худи, Поло и т.п.).
- **Size** — размер конкретного товара: буквенное (S/M/L/XL), числовое обозначение, количество на складе.
- **Order** — заказ: дата/время создания, статус, покупатель, список позиций.
- **OrderItem** — позиция заказа: товар, размер, количество, цена за единицу.

Для исключения зацикливания JSON при сериализации используется:

```csharp
builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
});
```

## Эндпоинты

### Авторизация (`/api/auth`)
- `POST /api/auth/register` — регистрация нового пользователя (доступно всем, роль User).
- `POST /api/auth/login` — вход, возвращает JWT-токен.

### Одежда (`/api/clothes`)
- `GET /api/clothes` — список всей одежды (без авторизации).
- `GET /api/clothes/search?name=` — поиск одежды по части названия (без авторизации).
- `PUT /api/clothes/sizes/{sizeId}/stock` — изменить количество товара размера (**менеджер**).
- `POST /api/clothes/{id}/remove-from-sale` — убрать товар из продажи (**менеджер**).
- `POST /api/clothes/{id}/restore-to-sale` — вернуть товар в продажу (**менеджер**).

### Заказы (`/api/orders`) — требуют авторизации
- `POST /api/orders` — создать новый заказ.
- `GET /api/orders/by-status?status=` — заказы с определённым статусом.
- `GET /api/orders/by-user/{userId}` — заказы определённого покупателя.
- `PUT /api/orders/{id}/status` — изменить статус заказа (**менеджер**).

## Тестирование

В папке `postman/` лежит коллекция `ClothesStore.postman_collection.json` — импортируйте её в Postman для демонстрации всех запросов.
